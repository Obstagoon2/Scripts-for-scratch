# scratch-code
neat little scripts for scratch
To Use
download
go to scratch 
open a project
click uplod sprite
upload the .sprite3 format file
